To MODIFY this bot:
-Open the enclosing directory in Explorer or Finder
-Double click on the .py file you want to edit
This will launch the Python editor

To run this bot:
Open your command line
Navigate to the folder using "cd"
type "python botskel.py"

Run example:
If the IRCBot folder is on your desktop:
"cd ~/Desktop/IRCBot"
"python botskel.py"

If the folder is in your user folder (the little house icon), you're probably already there, so just:
"cd IRC"
"python botskel.py"

NOTE:
Ignore the .pyc file. It's a temp file that the program generates when it's run.