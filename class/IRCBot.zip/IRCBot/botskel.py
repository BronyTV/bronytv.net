## TwitchyBot
##
## An IRC bot framework coded by the_amativeness, specifically for Twitchy
##
## Feel free to delete comments once you understand what things are for
## Everything after a hashmark is a comment, and is unnecessary
##
import sys          # this allows you to call the "quit" function later
import re           # this imports the "regular expressions" module
import socket       # this module allows us to connect to IRC via a shell socket
import imp          # this module allows us to re-import other modules
import trivia       # this is our custom-made trivia module
import time         # this module allows us to set timed delays

## SERVER INFO
server='irc.canternet.org' # apostrophes around text indicate a string
port=6669 # numbers without apostrophes are stored as raw numbers, instead of "text"

## BOT INFO
botnick='SampleBot' # Change this to something unique
botuser='SampleBot' # Change this to something unique
botname='A dumb friend' # The bot's "real name"
botpass='' # Put the NickServ password in here
botchan='#bronytv'
cmdchar='&' # this character is how we issue bot-specific commands. Make sure to use a character that other bots are NOT using.

## USER INFO (not necessary, but you can add "owner only" commands with this info)
admins=['Twitchy.bronytv.net','ama.bronytv.net'] # brackets indicate arrays

## First, we need to establish a socket (connection) to the server

s=socket.socket()   # this defines a "low level" connection to a server

# formatting note: periods are used to indicate functions
# the s= above references module "socket" (the first one)
# then the .socket() indicates function "socket" within the socket module

## Now, we need to open a connection to the IRC server
sc=0                # we create a temporary variable
while sc==0:        # and "while" that variable is true, do everything indented after the colon
        try:                              # we're gonna "try" to do everything here, and if we fail before completion, we'll do the "except"-ion defined at the end
                s.connect((server, port)) # we've already defined "s", so we're actually running socket.socket().connect()
                sc=1                      # if the connection was successful, we'll redefine the variable, ending the "while" loop
        except:                                                         # if we weren't successful, an "except"-ion occurs
                print('could not connect. trying again in 30 seconds.') # this line will be printed in your console window
                time.sleep(30)                                          # then we wait 30 seconds, and the loop will occur again (because "sc" is still equal to 0)

# note that /defining/ a variable uses ONE equal sign, and seeing IF something is equal uses TWO. You can also use <, <=, >, >=, and != (not equal). Technically <> also works as "not equal", but standard practice is to use !=

# also note the indentation. it's VERY important. It shows what code belongs to what "surrounding" statements. Everything between that "while:" and the next line of un-indented code is /part/ of the "while" statement. same goes for "try" and "except". standard practice is either 8 spaces, or a TAB. I prefer tabs.
# If your code isn't working, check the indentation to make sure it's correct, then do this: 1) select ALL the text. 2) go to Format>Tabify Region. 3) make sure the dialog box says "8", then hit OK. 4) save your work and try running the program again.

s.settimeout(130)            # if we don't get /any/ signal from the server in 130 seconds, it'll timeout and disconnect. normally, the server will ping you after 120 seconds of inactivity.

s.send('NICK '+botnick+'\r\n')                                   # this "sends" a command to our server socket. the \r means "end of line", and the \n means "carriage return". When you hit your enter key, it automatically 'creates' both of those characters. But here, we need to manually put them in.
s.send('USER '+botuser+' '+server+' B :'+botname+'\r\n')         # here, we're defining our "username" and "real name"
time.sleep(3)                                                    # now we wait 3 seconds, to make sure we're fully connected to the server, before:
s.send('PRIVMSG nickserv :IDENTIFY '+botnick+' '+botpass+'\r\n') # we IDENTIFY with NickServ

# note: we can concatenate strings together, using plus signs. "botnick" and "botpass" are strings we've already created.
# note: whitespace is important. note the ' ' between the nick and pass.

# s.send() is the command you'll use most often. It sends messages to the server for us.
# PRIVMSG is an IRC command telling the server we want to send a text message /somewhere/, to wherever is listed next.
# After we define the message type (privmsg) and the message destination (nickserv), we put a space and a colon, saying "this is the message".
# Everything after the colon will be sent to the destination; until we hit 'return', using "\r\n"

# note: we use the apostrophe to indicate strings. you could also use quotes, but things get a little tricky then.
# My suggestion: pick one and stick with it.
# using quotes allows you to put apostrophes in the message without "escaping" them. Escaping is done using a backslash. so "\n" is actually an "escaped" character, specifically a new line character
# using apostrophes allows you to put quotes in the message without escaping them. Since we use quotes in "pairs", but apostrophes only come once per use, normally, i prefer to use apostrophes for my strings.

s.send('JOIN '+botchan+'\r\n') # now that we've identified, let's connect to our channel
		
while True:                    # this statement will NEVER not be true. So it will loop forever, unless we BREAK out of it.
        try:
                line=s.recv(4096)  # this tries to receive a new line from the server, with a maximum "buffer" length
        except:
                s=socket.socket()  # if the receive wasn't successful, the bot assumes the connection dropped, and it tries to reconnect. The code here is /identical/ to the code above.
                sc=0
                while sc==0:
                        try:
                                s.connect((server, port))
                                sc=1
                        except:
                                print('could not connect. trying again in 30 seconds.')
                                time.sleep(30)
        try:
                print(line.split('\r\n', 1)[0]) # now, we attempt to print the incoming message in our console window, minus any extra carriage returns
        except:
                pass # "pass" means "do nothing". So if the try failed, nothing would happen. This prevents the bot from crashing.
        try: # let's "try" something else, an "if" statement:
                if line.split('@',1)[1].split(' ',1)[0] in admins and line.split(':',2)[2].split('\r\n',1)[0]==cmdchar+'die':
                # if we 'split' the 'line' at one spot, defined with an '@' symbol, and take the [1] result (more on this in a sec), and it's 'in' the array called "admins", AND
                # if we 'split' the 'line' at two spots, defined with ':' symbols, and take the [2] result, and it is EXACTLY EQUAL a string of the 'cmdchar' plus the word DIE, then we everything indented after the colon:
                        s.send('QUIT :Static Bot System closing down.\r\n') # we send a "quit" command to IRC
                        break # and we also BREAK out of our "while" loop.
        except:
                pass

# Note about arrays: computers count starting with ZERO. So if i wanted to know how many "G"s this is: GGG, a computer would count them "ZERO, ONE, TWO".
# So what we did above with the 'split', is we actually /created/ an array with parts. If we split it ONCE, we have TWO parts: parts ZERO and ONE.
# 'split' is used like this: STRING.split('character(s) to split at', number of times to search for it)[splits to retain]
# so the if statement above splits the string, and takes a specific part of it.
# Note that there are actually TWO different splits on that first definition: a split AFTER the @ symbol, and a split BEFORE the FIRST space.

# When a message comes in from that .recv(), it looks like this:
# :nick!user@hostmask msgtype msglocation :message
# So there's actually TWO colons: one at the very start, and one right before the message. So in the second part of the "IF", we're finding the second ":" and grabbing everything [after] it

        if line.find('PING :')!=-1:              # if our bot receives a ping from the server, it won't begin with a colon. It will say "PING :servername"
                s.send('PONG :'+server+'\r\n')   # so we have to reply with a PONG, or the server will time us out
        if line.find('PRIVMSG')!=-1:             # also of note, saying something is "not equal to negative one" is basically saying "yes". There are 3 states a computer variable can be in: "TRUE" (1), "FALSE" (0), and "NOTHING" (-1). We can't look at the word "hospital" and say "This word is TRUE". But we /can/ say "This word is NOT NOTHING". In other words, if we look for something, and DON'T NOT find it, then we've found it, right?
                imp.reload(trivia)       # first, we reload our custom module called "trivia.py". This way, we can make changes to the module while it's running, and it will always grab the most recent version
                try:
                        nick=line.split(':',1)[1].split('!',1)[0]               # a users nick is defined as between the first ":" and the "!"
                        host=line.split('@',1)[1].split(' ',1)[0]               # their hostmask is between the "@" and the first space
                        channel=line.split(' PRIVMSG ',1)[1].split(' :',1)[0]   # the channel is after the whitespace after "PRIVMSG", and before the colon
                        if channel==botnick:                                   # if the "incoming" channel is the bot's nick, then the "outgoing" channel will be the user's nick
                                channel=nick                                    # this allows a user to send a pm to the bot, and have the bot reply correctly
                        msg=line.split(' :',1)[1].split('\r\n',1)[0]            # this is the message we receive, minus any extra carriage returns
                except:
                        nick=' '          # if something happens, and the bot can't find all the info above, it will set everything to a single space, then print the error text below
                        host=' '
                        channel=' '
                        msg=' '
                        print('ERROR SPLITS OUT')
                trivia.trivia(s, nick, host, channel, msg, cmdchar, botchan, botnick, admins)          # finally, we run the "trivia" function defined in module "trivia.py", passing along the variables we list here
sys.exit() # if something causes us to BREAK out of the while loop, this will kill the program for us.
