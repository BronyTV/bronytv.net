##
## This is our actual "content". Make sure you read and understand the "botskel.py" file FIRST
##
##
import re
import sys
import random     # this allows us to run a random number generator
##
igcase=re.IGNORECASE  # this makes "igcase" a shorthand for ignoring ALL case-sensitivity in a search
##

## For this module, i'll mostly explain things /after/ each section
## Everything I've included here is OPTIONAL. Feel free to remove bits and pieces.
## You can also COMMENT OUT parts by putting hashes at the beginning of each line of a section

def trivia(s, nick, host, channel, msg, cmdchar, botchan, botnick, admins): # first, we define this new function, listing all variables being imported. Order of variables isn't important, as long as the NUMBER of variables matches
        if re.search('super secret twitchy trivia',msg,igcase):
                s.send('PRIVMSG '+channel+' :I like Twitchy\'s random trivia!\r\n')
                
## the re.search() function allows us to look in a string variable for a specific string
## in this case, we check EACH incoming message for the word 'trivia', ignoring all capital letters.
## if we find it, we do the indented thing
## We can have as many IF statements as we want at one level, and the bot will try them ALL. If we want to tell the bot to check one thing OR another, we can use IF/ELIF/ELSE
## i'm putting an example of a more complicated "if" statement here, to show how IF/ELIF/ELSE works:

#        if re.search('ponies',msg,igcase):
#                s.send('PRIVMSG '+channel+' :I like ponies!\r\n')
#        elif re.search('puppies',msg,igcase):
#                s.send('PRIVMSG '+channel+' :Puppies are ok, i guess...\r\n')
#        else:
#                s.send('PRIVMSG '+channel+' :I hate that.\r\n')
#        ##reference point

## Note how that works: the computer tries the IF statement. if successful, it runs the indented code, then jumps to AFTER the else statement, where the reference point is.
## If the IF statement fails, only then does it try the ELIF statement (else if).
## Same thing, if successful, it runs the indented code, then goes to the reference point.
## if it fails again, it moves to the next ELIF and the next, and the next.
## You can have as many ELIFs as you want. If for some reason, the IF and all the ELIF statements fail, we run the ELSE statement.
## I would /not/ recommend actually running the above code, as the bot would respond to EVERY message said. It would spam the chat like crazy.

## Now we get to the fun part: responding to commands:
        if msg.startswith(cmdchar):
                cmd=msg.split(' ',1)[0].split(cmdchar,1)[1].lower()
                try:
                        operand=msg.split(' ',1)[1].split('\r\n')[0]
                except:
                        operand=''

## This big hunk of a statement is how Static does 95% of his work.
## First, we check for our command character at the beginning of the line.
## Next, we define our command to be everything after the command character, but before the first space.
## So if the character is "&", and i say "&do stuff", the command is "do"
## Because of the ".lower()", the command will ALWAYS be lower case. This makes coding easier.
## Next, we attempt to define the rest of the message as our "operand"
## That way, we can tell the bot to do "stuff" within the command
## Example: ~stream pony <-- this tells Static to "stream" something, and that "pony" is important
## Odds are you probably won't use the operand that often, but it's good to have in there for now.

                # Because everything from this point is within the IF statement above, ALL code should be indented to this point

                if cmd=='trivia' and host in admins:
                        rndint=random.randint(1,42)  # create a random integer. Change the second number to be however many facts you have. 
                        if rndint==1:    # each random fact gets its own if statement to check for that number.
                                emsg='Ashleigh Ball (Voice of Rainbow Dash and AppleJack) once threatened to leave the show if AJ\'s parents were ever shown.'
                        if rndint==2:
                                emsg='Trixie was originally male and was going to be a jealous younger sibling of Twilight who would constantly try to out-do her throughout the series. She was later changed to being female and her role was shortened considerably, instead acting as a re-occurring rival of sorts.'
                        if rndint==3:
                                emsg='Madeline Peters (Voice of Scootaloo) Originally sang the Cutie Mark Crusader\'s Song so well that the directors had to ask her to try and sing poorly.'
                        if rndint==4:
                                emsg='It was Claire Corlett\'s ((Voice of Sweetie Belle) idea that Sweetie Belle would sing the song at the campfire in Sleepless in Ponyville poorly. She thought it would be hilarious.'
                        if rndint==5:
                                emsg='Andrea Libman cannot hold Pinkie Pie\'s voice and sing at the same time for longer than 5 seconds as it strains her own voice to do so. As such, Shannon Chan-Kent was hired to sing for her.'
                        if rndint==6:
                                emsg='Ashliegh Ball (Voice of Rainbow Dash and Applejack) is the only actress in the main cast that does the singing for all of her characters. Tara Strong has a vocal replacement due to not being able to sound like Twilight when singing, Tabitha St. Germain can\'t really sing and Andrea Libman can only sing as Fluttershy.'
                        if rndint==7:
                                emsg='Rarity originally had an episode lined up for Season 3 but it was cut when it was decided to cut the season down so production on Equestria Girls could begin.'
                        if rndint==8:
                                emsg='Trixie was originally supposed to return in Season 2 but didn\'t due to circumstances involving scripting. It is unknown what her role would have been.'
                        if rndint==9:
                                emsg='Rainbow Dash is the only member of the mane 6 to have a cutie mark that is a single symbol. AppleJack, Rarity, Fluttershy and Pinkie Pie all have clusters of 3 as their marks and Twilights is a large sparkle with 5 smaller sparkles surrounding it.'
                        if rndint==10:
                                emsg='When the mane 6 first use the Elements of Harmony, the position they are initially shown in resemblers Twilight\'s Cutie mark with the other five surrounding her.'
                        if rndint==11:
                                emsg='Pinkie Pie\'s full name is Pinkamena Diane Pie. At this time she is the only character on the show to have a human name, "Diane".'
                        if rndint==12:
                                emsg='The character of Celestia was origannly going to be Queen Celestia, But Hasbro executives decided the title of "Queen" was more commonly associated with villains, thanks to Disney. The title would later be used for a villain with Queen Chrysalis.'
                        if rndint==13:
                                emsg='The background character of Bon Bon has a different voice actress every time she speaks, usually Nicole Oliver or Tabitha St. Germain.'
                        if rndint==14:
                                emsg='The Cutie Mark Crusaders were originally one character, Applebloom. She was split into 3 however when it was decided they wanted a filly of each race as part of the main cast.'
                        if rndint==15:
                                emsg='Tara Strong is the only actress in the cast to only voice one character, Twilight Sparkle.'
                        if rndint==16:
                                emsg='Trixie and Derpy originally were in A Canterlot Wedding, but both were cut for time from the final draft of the episode. Animatics of Derpy were made, but Trixie\'s scene was never filmed or even recorded.'
                        if rndint==17:
                                emsg='Stay Tuned during the credits of Equestria Girls for a little surprise from Hasbro.'
                        if rndint==18:
                                emsg='As of Season 3, Rainbow Dash is the only member of the Mane 6 who has not gotten her own solo song. She does however have a duet with Fluttershy in "Find a Pet".'
                        if rndint==19:
                                emsg='The series has made at least 2 references to the popular fan fiction "Fallout Equestria". Zecora calls Pipsqueak "Little Pip" in Luna Eclipsed and Calamity appears among the ponies watching Rainbow Dash\'s video in Hurricane Fluttershy.'
                        if rndint==20:
                                emsg='The shooting stars seen in Apple Family Reunion are meant to be Aj\'s parents. According to the writers, Producers and Ashligh Ball (Aj\'s voice actress) they are infact dead and this was confirmation.'
                        if rndint==21:
                                emsg='Queen Chrysalis is the only character in the show to serve a large role but never be named on screen.'
                        if rndint==22:
                                emsg='There is alternate dialogue for the scene in Spike at Your Service when Rainbow Dash knocks over the stone wall. Originally when asked if she was ok, show was going to respond "I like the Purple Pony". The dialogue was changed to avoid any references to her being a lesbian, which, according to the writers, she\'s not.'
                        if rndint==23:
                                emsg='Andrea Libman once got so into character as Fluttershy that she accidentally swore using Fluttershy\'s voice'
                        if rndint==24:
                                emsg='Fluttershy was originally an earth pony who usually refused to leave her cabin. Angel was also originally a chipmunk'
                        if rndint==25:
                                emsg='Pinkie Pie was originally a Pegasus named Surprise. Surprise\'s character model and name was reused for a Wonderbolt.'
                        if rndint==26:
                                emsg='When asked if Spike and Rarity actually had a chance as a couple, most of the writers and actors agree that he has a better chance with Sweetie Belle than Rarity as she is simply "Much older than him".'
                        if rndint==27:
                                emsg='King Sombra\'s design is loosely based on Aku from Samurari Jack.'
                        if rndint==28:
                                emsg='Twilight Sparkle is the only good character on the show who has "died". She died when she was turned to stone by the cockatrice.'
                        if rndint==29:
                                emsg='When Twilight Sparkle is zapped by the Elements of Harmony and sent to "limbo", She leaves a scorch mark on the floor that is the shape of her Cutie Mark.'
                        if rndint==30:
                                emsg='Magical Mystery Cure was comprised from two separate episode scripts and ideas. It was made into one episode to save time. One of those ideas started as a joke, when someone asked "what if AJ had to take over Rarity\'s job for a day"'
                        if rndint==31:
                                emsg='Trixie has Magenta Eyes. Magenta does not actually exist; it is a trick your brain plays on you.'
                        if rndint==32:
                                emsg='Tabitha St. Germain did not actually know Derpy was female when she recorded her voice. She based her voice off a little boy from her neighborhood who had Down Syndrome.'
                        if rndint==33:
                                emsg='Sunset Shimmer is Celestia\'s former student before Twilight and is voiced by Rebbeca Shoichet, Twilight\'s singing voice. Coincidence?'
                        if rndint==34:
                                emsg='Britt McKillip (voice of Princess Cadance) performed the entire song This Day Aria in one go by herself'
                        if rndint==35:
                                emsg='This Day Aria\'s title is a joke as an Aria is a deceptive form of music. In it Chrysalis sings about how she deceived everyone and several Aria\'s are used.'
                        if rndint==36:
                                emsg='Zecora has only ever spoken out of rhyme once when she yells at Twilight, "Have you gone mad?"'
                        if rndint==37:
                                emsg='Lee Tocker, Peter New, and Richard Ian Cox often compete over who gets to voice a new male character when they are introduced.'
                        if rndint==38:
                                emsg='Shannon Chan-Kent (Singing voice of Pinkie Pie) supplies the voice of Silver Spoon.'
                        if rndint==39:
                                emsg='The voice actresses behind the CMC (Claire Corlett as Sweetie Belle, Madeleine Peters as Scootaloo, and Michelle Creber as Applebloom) almost always record their lines together in the same booth. This is a rare occurrence for cartoons as Voice actresses and actors often record their lines in separate booths and at different times.'
                        if rndint==40:
                                emsg='The line "Friendship is Magic" was never spoken in the series until Discord says it in Season 3.'
                        if rndint==41:
                                emsg='Babs Seed is voiced by Brynna Drummond, daughter of Brian Drummond, who voices Mr. Cake.'
                        if rndint==42:
                                emsg='Tabitha St. Germain holds the record for most voices on the show. Her credits include: Rarity, Princess Luna, Nightmare Moon, Granny Smith, Bon Bon, Mrs. Cake, Derpy (the original voice), Pound Cake, Philomina, Photo Finish, and a gravy boat.'
                        s.send('PRIVMSG '+channel+' :Did you know: '+emsg+'\r\n')

## For right now, only users whose hostmask is in the "admins" array can use this command.
## This allows us to debug the bot.
